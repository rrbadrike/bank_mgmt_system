

1.import demo.sql database in phpmyadmin

2.go in project application/config/database.php set username,password,and database name

3.start apache and mysql

4.visit url http://localhost/demo/login  in this case "demo" is my project folder name

username:admin
password:123456