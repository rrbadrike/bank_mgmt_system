<?php

class User_model extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->response = array(
            'status' => 0,
            'msg' => '',
            'error' => '',
            'error_array' => array(),
            'data' => array()
        );
    }

    function user_list(){
        $url = array();
        $where = array();
        $main_url = site_url('admin/User');
        $having=array();
        $response = array();
        $response['name'] = '';
        $response['mobile'] = '';
        $response['account_no'] = '';
       
        
        $name=trim($this->input->get('name'));
        if(!empty($name)){
            $where['(u.name like "%'.$name.'%" or u.mobile like "%'.$name.'%")']=null;
            $response['name'] = $name;
            $url[] = 'name=' . $name;
        }

        $mobile=trim($this->input->get('mobile'));
        if(!empty($mobile)){
            $where['mobile like ']='%'.$mobile.'%';
            $response['mobile'] = $mobile;
            $url[] = 'mobile=' . $mobile;
        }
        $account_no=trim($this->input->get('account_no'));
        if(!empty($account_no)){
            $where['account_no']=$account_no;
            $response['account_no'] = $account_no;
            $url[] = 'account_no=' . $account_no;
        }

        
        $page = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);
        if (isset($_GET['per_page']) && !empty($_GET['per_page'])) {
            $per_page = $_GET['per_page'];
            $url[] = 'per_page=' . $per_page;
        } else {
            $per_page = 25;//PER_PAGE;
            $url[] = 'per_page=' . $per_page;
        }
        $response['page'] = $page;
        $response['per_page'] = $per_page;
        $num_rows = $this->db->select('u.id')
        ->where($where)
        // ->where('usertype',2)
         ->where('u.is_delete',0)
        ->order_by('u.id','desc')
        ->get('users as u')->num_rows();
        
        $response['num_rows'] = $num_rows;
        $response['url'] = $main_url . '?' . implode('&', $url) . '&';

        $response['list']= $this->db->select('*')
        ->where($where)
       // ->where('usertype',2)
        ->where('u.is_delete',0)
        ->get('users as u', $per_page, ($per_page * ($page - 1)))
        ->result_array();
     
        $this->response = $response;
       
        return $this->response;
    }

    

    function dashboard_history_list(){
        $response['list']= $this->db->select('u.*')
        ->where('u.is_delete',0)
        ->group_by('u.id')
        ->get('users as u',0,20)
        ->result_array();
        if(!empty($response['list'])){
            foreach ($response['list'] as $key => $value) {
              $curr_bal=0;
              $data= $this->db->select('new_value,e.on_date')
              ->where('a.user_id',$value['id'])
              ->order_by('a.id','desc')
              ->join('entries e','e.id=a.entry_id','left')
              ->get('audit a')->row_array();
                 if(!empty($data['new_value'])){
                    $curr_bal=$data['new_value'];
                 }
                $response['list'][$key]['curr_bal']=$curr_bal;
                $response['list'][$key]['on_date']=$data['on_date'];
            }
        }
     
        $this->response = $response;
       
        return $this->response;
    }

    function get_data($user_id){
     return $this->db->where('id',$user_id)->get('users')->row_array();
    }

    function get_last_id(){
        $data= $this->db->order_by('id','desc')->get('users')->row_array();
        $last_id=1;
        if(!empty($data)){
         $last_id= $data['id']+1;  
        }
        $acc='ABC-'.$last_id;
        return $acc;
    }
	
	

    function add_user_db(){
        $this->form_validation->set_rules('account_no','account no ','trim|required');
        $this->form_validation->set_rules('full_name','full name ','trim|required');
        $this->form_validation->set_rules('mobile','mobile ','trim|required|numeric');
       
        
        if($this->form_validation->run() == TRUE){
        
            $insert = array();
            $insert['account_no'] = $this->input->post('account_no');
            $insert['name'] = $this->input->post('full_name');
            $insert['mobile'] = $this->input->post('mobile');
          
            $id = $this->input->post('id');
            if(isset($id) && !empty($id)){
                 $check=$this->db->where('id!=',$id)->where('mobile',$this->input->post('mobile'))->get('users')->num_rows();
                 if($check>0){
                      
                 $this->response['status'] = 0;
                 $this->response['error'] = 'This mobile already exist';
                 }else{
                   $this->db->where('id', $id)->update('users', $insert);
                   $this->response['status'] = 1;
                   $this->response['redirect_url'] = site_url('admin/User');
                   $this->response['msg'] = 'User updated successfully';
                 }
            }else{
                 $check=$this->db->where('account_no',$this->input->post('account_no'))->get('users')->num_rows();
                 if($check>0){
                    $insert['account_no'] = $this->get_last_id();
                 }else{
                     $this->db->insert('users', $insert);
                     $this->response['status'] = 1;
                     $this->response['redirect_url'] = site_url('admin/User');
                     $this->response['msg'] = 'User added successfully';
                 }
                
            }
        }else{
            $this->response['error_array'] = $this->form_validation->error_array();
        }
        return $this->response;
    }

    function delete_user($id) {
       // $id = substr(base64_decode($_POST['id']), 14);
        $this->db->where('id',$id)->update('users',array('is_delete'=>1));
        $return = array('status' => '1', 'msg' => 'User Deleted succesfully');
        $return['redirect_url']=site_url('admin/User');
        return $return;
    }

  

}