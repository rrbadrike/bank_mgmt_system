<?php
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
class Data_model extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->response = array(
            'status' => 0,
            'msg' => '',
            'error' => '',
            'error_array' => array(),
            'data' => array()
        );
    }

   

    function get_data($acc_no){

         $mydata= $this->db->where("(account_no='".$acc_no."' or mobile='".$acc_no."')")->get('users')->row_array();
          $mydata['curr_bal']=0;
         if(!empty($mydata['account_no'])){
             $data=$this->db->select('id')->where('account_no',$mydata['account_no'])->get('users')->row_array();
            
             if(!empty($data['id'])){
                $res=$this->db->select('new_value')->where('user_id',$data['id'])->order_by('id','desc')->get('audit')->row_array();

                if(!empty($res['new_value'])){
                    $mydata['curr_bal']=$res['new_value'];
                }
             }
         }
         return $mydata;
    }

    function deposit_db($added_by=''){
        $this->form_validation->set_rules('account_no','account no ','trim|required');
        $this->form_validation->set_rules('deposit','Deposit Amount ','trim|required|numeric');
        $this->form_validation->set_rules('id','ID ','trim');

        if($this->form_validation->run() == TRUE){
        
            $insert = array();
            $insert['user_id'] = $this->input->post('id');
            $insert['credit'] = $this->input->post('deposit');
            $insert['currency'] = "INR";
            $insert['on_date'] = date('Y-m-d h:i:s');
            $this->db->insert('entries',$insert);
             $ins_id=$this->db->insert_id();

            //update audit table
             if(!empty($ins_id)){

                 $last_bal=0;
                 $data=$this->db->select('new_value')->where('user_id',$this->input->post('id'))->order_by('id','desc')->get('audit')->row_array();
                 if(!empty($data['new_value'])){
                     $last_bal =$data['new_value'];
                 } 
                 $insert = array();
                 $insert['user_id'] = $this->input->post('id');
                 $insert['entry_id'] = $ins_id;
                 $insert['old_value'] = $last_bal;
                 $insert['new_value'] = $last_bal+$this->input->post('deposit');
                 $insert['transaction_type']=1;
                 $this->db->insert('audit',$insert);
                 $this->response['redirect_url'] = site_url('admin/Data/deposit');
                 $this->response['status'] = 1;
                 $this->response['msg'] = 'Amount Deposited successfully';
             }
            
        }else{
            $this->response['error_array'] = $this->form_validation->error_array();
        }
        return $this->response;
    }
	
	function withdraw_db() {
        $this->form_validation->set_rules('account_no','account no ','trim|required');
        $this->form_validation->set_rules('withdraw','withdraw Amount ','trim|required|numeric');
        $this->form_validation->set_rules('id','ID ','trim');

        if($this->form_validation->run() == TRUE){
         $curr_bal=trim($this->input->post('curr_bal'));
         $withdraw_amt=trim($this->input->post('withdraw'));

            if($curr_bal>=$withdraw_amt){
                $insert = array();
                $insert['user_id'] = $this->input->post('id');
                $insert['debit'] = $withdraw_amt;
                $insert['currency'] = "INR";
                $insert['on_date'] = date('Y-m-d h:i:s');
                $this->db->insert('entries',$insert);
                 $ins_id=$this->db->insert_id();

                //update audit table
                 if(!empty($ins_id)){

                     $last_bal=0;
                     $data=$this->db->select('new_value')->where('user_id',$this->input->post('id'))->order_by('id','desc')->get('audit')->row_array();
                     if(!empty($data['new_value'])){
                         $last_bal =$data['new_value'];
                     } 
                     $insert = array();
                     $insert['user_id'] = $this->input->post('id');
                     $insert['entry_id'] = $ins_id;
                     $insert['old_value'] = $last_bal;
                     $insert['new_value'] = $last_bal-$withdraw_amt;
                     $insert['transaction_type']=2;
                     $this->db->insert('audit',$insert);
                     $this->response['redirect_url'] = site_url('admin/Data/withdraw');
                     $this->response['status'] = 1;
                     $this->response['msg'] = 'Amount Withdrawl successfully';
                 }
            }else{
                   $this->response['status'] = 0;
                   $this->response['error'] = 'withdraw Amount should be less than current balance';
            }
            
        }else{
            $this->response['error_array'] = $this->form_validation->error_array();
        }
        return $this->response;
    }

    function delete_member($id) {
       // $id = substr(base64_decode($_POST['id']), 14);
        $this->db->where('id',$id)->update('members',array('is_delete'=>1));
        $return = array('status' => '1', 'msg' => 'Member Deleted succesfully');
        $return['redirect_url']=site_url('admin/Data');
        return $return;
    }

   
    

    function transaction_list(){
         $url = array();
        $where = array();
        $main_url = site_url('admin/Data');
        $having=array();
        $response = array();
        $response['name'] = '';
        $response['account_no'] = '';
        $response['mobile'] = '';
        $name=trim($this->input->get('name'));
        if(!empty($name)){
            $where['(u.name like "%'.$name.'%" )']=null;
            $response['name'] = $name;
            $url[] = 'name=' . $name;
        }

        $account_no=trim($this->input->get('account_no'));
        if(!empty($account_no)){
            $where['account_no']=$account_no;
            $response['account_no'] = $account_no;
            $url[] = 'account_no=' . $account_no;
        }
        
        $mobile=trim($this->input->get('mobile'));
        if(!empty($mobile)){
            $where['mobile like']='%'.$mobile.'%';
            $response['mobile'] = $mobile;
            $url[] = 'mobile=' . $mobile;
        }
        
        
        $page = (isset($_GET['page']) && !empty($_GET['page']) ? $_GET['page'] : 1);
        if (isset($_GET['per_page']) && !empty($_GET['per_page'])) {
            $per_page = $_GET['per_page'];
            $url[] = 'per_page=' . $per_page;
        } else {
            $per_page = 25;//PER_PAGE;
            $url[] = 'per_page=' . $per_page;
        }
        $response['page'] = $page;
        $response['per_page'] = $per_page;
        $num_rows = $this->db->select('e.*,u.name,u.mobile,u.account_no')
        ->where($where)
        ->join('users as u','u.id=e.user_id','left')
        ->order_by('e.id','desc')
        ->get('entries as e')->num_rows();
        
        $response['num_rows'] = $num_rows;
        $response['url'] = $main_url . '?' . implode('&', $url) . '&';
        $this->response=$response;
        $this->response['list']= $this->db->select('e.*,u.name,u.mobile,u.account_no')
        ->where($where)
        ->join('users as u','u.id=e.user_id','left')
        ->order_by('e.id','desc')
        ->get('entries as e')
        ->result_array();
       
        return $this->response;
     }

     


}