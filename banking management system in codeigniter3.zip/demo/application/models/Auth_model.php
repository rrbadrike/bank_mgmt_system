<?php

class Auth_model extends CI_Model {

	function __construct() {
		parent::__construct();
		$this->response = array(
			'status' => 0,
			'msg' => '',
			'error' => '',
			'error_array' => array(),
			'data' => array()
		);
	}

	private $verify_validation = array(
									array('field' => 'username', 'label' => 'Username', 'rules' => 'trim|required'),
									array('field' => 'password', 'label' => 'Password', 'rules' => 'trim|required')
									);

	function verify() {
		$this->form_validation->set_rules($this->verify_validation);
		if($this->form_validation->run() == TRUE){
			$user = $this->db->where('username', $_POST['username'])
	        				 ->where('password', $_POST['password'])
	        				 ->get('admin_login')
	        				 ->row_array();
	        				
			 if(!empty($user)){
			 	
			 	$admin_data = array();
			 	$admin_data['user_id'] = $user['id'];
			 	$admin_data['username'] = $user['username'];
			 	$this->session->set_userdata('admin', $admin_data);
			 	$this->response['redirect_url'] = site_url('admin/Dashboard');
			 	$this->response['status'] = 1;
			 	$this->response['msg'] = 'Logged in successfully';
			 }else{
			 	$this->response['error'] = 'Invalid Credentials';
			 }
		}else{
			$this->response['error_array'] = $this->form_validation->error_array();
		}
        return $this->response;
	}

}