<?php $this->load->view('include/header'); ?>
<!-- <link href="<?php //echo base_url(); ?>web_theme/css/submitstyle.css" rel="stylesheet">-->
<style>
	.my-button{
		color: white;
	    background: #9fd07c;
	    padding: 10px 30px;
	    border: none;
	    border-radius: 5px;
	}
</style>

<div class="container mt-5" style="text-align: center;min-height: 247px;font-size: 20px">
	<div class="row">
		<div class="col-lg-2"></div>
		<div class="col-lg-6">
			<div class="alert alert-danger py-4"><?php echo  $error; ?></div>
			
         </div>
    </div>
</div>

<?php $this->load->view('include/footer'); ?>