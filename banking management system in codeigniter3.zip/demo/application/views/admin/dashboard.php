<?php $this->load->view('admin/common/header') ?>

    <!-- BEGIN: Content-->
    <div class="app-content content ">
      <div class="content-overlay"></div>
      <div class="header-navbar-shadow"></div>
      <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
          <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h2 class="content-header-title float-left mb-0">Dashboard</h2>
                <div class="breadcrumb-wrapper">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Dashboard</a>
                    </li>
                  <!--   <li class="breadcrumb-item active">Dashbaord
                    </li> -->
                  </ol>
                </div>
              </div>
            </div>
          </div>

         <!--  <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
            <div class="form-group breadcrumb-right">
              <div class="dropdown">
                <button class="btn-icon btn btn-primary btn-round btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i data-feather="grid"></i></button>
              
              </div>
            </div>
          </div> -->
          
        </div>
        <div class="content-body">
  <div class="ajax-msg"></div>
<div class="row" id="basic-table">
        <div class="col-0"></div>
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">Recent Customers History  </h4> 
      </div>
              
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>Sr. No.</th>
              <th>Customer Name</th>
              <th>Mobile</th>
              <th>Account No</th>
              <th>Current Balance</th>
              <th>On Date</th>
            </tr>
          </thead>
          <tbody>
           <?php if(!empty($list)){
                 $i=0;
                    foreach ($list as $key => $value) {
                      $i++;
              ?>
            <tr>
              <td>
               <?php echo $i ?>
              </td>
              <td><?php echo $value['name'] ?></td>
              <td><?php echo $value['mobile'] ?></td>
              <td><?php echo $value['account_no'] ?></td>
              <td><?php echo $value['curr_bal'] ?></td>
              <td><?php echo date('d M Y h:i:a',strtotime($value['on_date'])) ?></td>
              
            </tr>
        <?php }}?>
         
          </tbody>
        </table>
        
      </div>
        <?php //echo pagination($num_rows, $per_page, $page, $url); ?>
    </div>
    
  </div>
</div>
        </div>
       </div>
      </div>
      <!-- end ccontent -->
        




<?php $this->load->view('admin/common/footer') ?>