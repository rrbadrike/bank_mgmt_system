<?php $this->load->view('admin/common/header') ?>
<?php 

if(!empty($edit)){
	$id=$edit['id'];	
	$source=$edit['name'];
	$is_active=$edit['is_active'];
	
}else{
	$id="";	
	$source="";	
	$is_active=1;	

}
	?>


    <!-- BEGIN: Content-->
    <div class="app-content content ">
      <div class="content-overlay"></div>
      <div class="header-navbar-shadow"></div>
      <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
          <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h2 class="content-header-title float-left mb-0">Add Source</h2>
                <div class="breadcrumb-wrapper">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Master</a>
                    </li>
                    <li class="breadcrumb-item active">Add Source
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

         <!--  <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
            <div class="form-group breadcrumb-right">
              <div class="dropdown">
                <button class="btn-icon btn btn-primary btn-round btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i data-feather="grid"></i></button>
              
              </div>
            </div>
          </div> -->

        </div>
        <div class="content-body"><!-- Horizontal Wizard -->
        	<div class="ajax-msg"></div>
			<section class="horizontal-wizard">
			  <div class="bs-stepper horizontal-wizard-example">
			  
			    <div class="bs-stepper-content">
			      <div id="account-details" class="content">
			        <div class="content-header">
			          <h5 class="mb-0">Source</h5>
			          <!-- <small class="text-muted">Enter Your Account Details.</small> -->
			        </div>
			        <form action="<?php echo site_url('admin/Master/source_add_db') ?>" method="post" class="ajax-form">
			          <div class="row ">
			          	<input type="Hidden" name="id" value="<?php echo $id ?>">
			            <div class="form-group col-md-4 ajax-field">
			              <label class="form-label" for="username">Source Name</label>
			              <input type="text" name="source" id="source" class="form-control" placeholder="source" value="<?= $source?>" />
			               <div class="ajax-error"></div>
			            </div>
			          
			              <div class="form-group col-md-4 ajax-field">
			              <label class="form-label" for="username">Active</label>
				              <div>
				              	 <input type="radio" name="active" id="active" <?php echo ($is_active==1)?'checked':'' ?> value="1" /> Yes 
				                 <input type="radio" name="active" id="inactive"  value="0" <?php echo ($is_active==0)?'checked':'' ?> class="ml-1" /> No 
				              </div>
			                 <div class="ajax-error"></div>
			               </div>
			          </div>
			           <div class="d-flex justify-content-between">
			          <button class="btn btn btn-primary " >
			           <span class="align-middle d-sm-inline-block d-none">Save</span>
			          </button>
			        
			        </div>
			        </form>
			       
			      </div>
			  <!-- /Horizontal Wizard -->   
			     
			   

			     
			    </div>
			  </div>
			</section>
        </div>
       </div>
      </div>
      <!-- end ccontent -->



   

<?php $this->load->view('admin/common/footer') ?>

  <script type="text/javascript">
      $(document).ready(function(){
        
        $(document).on('submit', '.ajax-form', function(e){
          e.preventDefault();
          clearAjaxErrors();
          var url = $(this).attr('action');
          var data = $(this).serializeArray();
          $.post(url, data, function(res){
            processAjaxResponse(res);
          }, 'json');
        });

      });
    </script>