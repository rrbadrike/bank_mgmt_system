<?php $this->load->view('admin/common/header') ?>
<?php 

if(!empty($edit)){
	$id=$edit['id'];	
	$first_name=$edit['first_name'];
	$last_name=$edit['last_name'];
	$email=$edit['email'];
	$username=$edit['username'];
	$is_active=$edit['is_active'];
	$p=$edit['p'];
}else{
	$id="";	
	$first_name="";	
	$last_name="";	
	$email="";	
	$username="";	
	$is_active="";	
	$p="";
}
	?>


    <!-- BEGIN: Content-->
    <div class="app-content content ">
      <div class="content-overlay"></div>
      <div class="header-navbar-shadow"></div>
      <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
          <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h2 class="content-header-title float-left mb-0"> Source List</h2>
                <div class="breadcrumb-wrapper">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Master</a>
                    </li>
                    <li class="breadcrumb-item active"> Source List
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

          <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
            <div class="form-group breadcrumb-right">
              <div class="dropdown">
                <button class="btn-icon btn btn-primary btn-round btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="window.location='<?php echo site_url("admin/Master/source_add") ?>'">Add New Source</button>
              
              </div>
            </div>
          </div> 

        </div>
        <div class="content-body">

   <div >
     <div class="card">
     	 <form>
     	    <div class="row card-body">
			         
			            <div class="form-group col-md-3 ajax-field">
			              <label class="form-label" for="username">Source</label>
			              <input type="text" name="source" id="source" class="form-control" placeholder="source" value="<?= $source?>" />
			               
			            </div>
			          

			             <div class="form-group col-md-3 ajax-field ajax-field">
			             	 <div>&nbsp;</div>
							 
			             <button class="btn btn-primary">Search</button>
			             </div>
			          
			 </div>
		 </form>
     </div>
   </div>

        	<!-- Horizontal Wizard -->
        	<div class="ajax-msg"></div>
			<div class="row" id="basic-table">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">Source List</h4>
      </div>
                  <?php
                     $starts_from = ($per_page * ($page - 1)) + 1;
                     $end_to = $starts_from + $per_page - 1;
                     if ($end_to > $num_rows) {
                       $end_to = $num_rows;
                     }
                     $entries_text = "Showing " . $starts_from . " to " . $end_to . " of " . $num_rows . " entries";
                     ?>
          <p class="card-text ml-1"><?php echo $entries_text; ?></p>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>Sr. No.</th>
              <th>Source</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
           <?php if(!empty($list)){
           	     $i=0;
                    foreach ($list as $key => $value) {
                    	$i++;
             	?>
            <tr>
              <td>
               <?php echo $i ?>
              </td>
              <td><?php echo $value['name'] ?></td>
             <td><?php echo ($value['is_active']==1)?'<span class="badge badge-pill badge-light-success mr-1">Active</span>':'<span class="badge badge-pill badge-light-danger mr-1">In-Active</span>';?></td>
              <td>
                <div class="dropdown">
                  <button type="button" class="btn btn-sm dropdown-toggle hide-arrow" data-toggle="dropdown">
                    <i data-feather="more-vertical"></i>
                  </button>
                  <div class="dropdown-menu">
                    <a class="dropdown-item" href="<?php echo site_url('admin/Master/source_add/'.base64_encode($value['id']))?>">
                      <i data-feather="edit-2" class="mr-50"></i>
                      <span>Edit</span>
                    </a>
                    <a class="dropdown-item delete" href="javascript:void(0);" data-id="<?php echo base64_encode($value['id'])?>">
                      <i data-feather="trash" class="mr-50"></i>
                      <span>Delete</span>
                    </a>
                  </div>
                </div>
              </td>
            </tr>
        <?php }}?>
         
          </tbody>
        </table>
        
      </div>
        <?php echo pagination($num_rows, $per_page, $page, $url); ?>
    </div>
    
  </div>
</div>
        </div>
       </div>
      </div>
      <!-- end ccontent -->
        


  

<?php $this->load->view('admin/common/footer') ?>

  <script type="text/javascript">
      $(document).ready(function(){
        
        $(document).on('submit', '.ajax-form', function(e){
          e.preventDefault();
          clearAjaxErrors();
          var url = $(this).attr('action');
          var data = $(this).serializeArray();
          $.post(url, data, function(res){
            processAjaxResponse(res);
          }, 'json');
        });

         $(document).on('click', '.delete', function(e){
          e.preventDefault();
          clearAjaxErrors();
	          if(confirm("Are you sure to delete?")){
	          	  var id=$(this).attr('data-id');
	              var url="<?php echo site_url('admin/Master/delete_source/')?>"+id;
		          $.post(url, {id:id}, function(res){
		            processAjaxResponse(res);
		          }, 'json');
	          }
          
        });

      });
    </script>