<?php $this->load->view('admin/common/header') ?>
<?php 

if(!empty($edit['id'])){
	$id=$edit['id'];	
	$full_name=$edit['name'];
	$mobile=$edit['mobile'];
	//$is_active=$edit['is_active'];
	$account_no=$edit['account_no'];
	$curr_bal=$edit['curr_bal'];
	
}else{
	$id="";	
	$full_name="";	
	$mobile="";	
	$curr_bal="";	
	$account_no="";	
	$curr_bal="";
}
	?>
<style type="text/css">
	.table{
		border: 1px solid lightgray;
	}
</style>

    <!-- BEGIN: Content-->
    <div class="app-content content ">
      <div class="content-overlay"></div>
      <div class="header-navbar-shadow"></div>
      <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
          <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h2 class="content-header-title float-left mb-0">Deposit Amount</h2>
                <div class="breadcrumb-wrapper">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Transaction</a>
                    </li>
                    <li class="breadcrumb-item active">Deposit Amount
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

         <!--  <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
            <div class="form-group breadcrumb-right">
              <div class="dropdown">
                <button class="btn-icon btn btn-primary btn-round btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i data-feather="grid"></i></button>
              
              </div>
            </div>
          </div> -->

        </div>
        <div class="content-body"><!-- Horizontal Wizard -->
        	<div class="ajax-msg"></div>
			<section class="horizontal-wizard">
			  <div class="bs-stepper horizontal-wizard-example">
			  
			    <div class="bs-stepper-content">
			      <div id="account-details" class="content">
			        <div class="content-header">
			          <h5 class="mb-0">User Details</h5>
			          <?php 
                        $search=!empty($_GET['account_no'])?$_GET['account_no']:'';
			          if(empty($edit['id']) && !empty($_GET['account_no'])){ 
                             
			          	?>
			           <h6 class="alert alert-danger my-2 p-1" style="width:fit-content"><?php echo (empty($edit['id']) && !empty($_GET['account_no']))?'User not found':'' ?></h6> 
			          <?php } ?>
			        </div>
			      <form action="" method="get" >
			          <div class="row ">
			          	  
			          
			           
			            <div class="form-group col-md-3 ajax-field">
			              <label class="form-label" for="email">Account Number/mobile</label>
			              <input type="text" name="account_no" id="first_name" class="form-control" placeholder="" aria-label="john.doe" value="<?php echo $search ?>"
			              />
			              <div class="ajax-error"></div>
			               
			            </div>
			              <div class="form-group col-md-3 ajax-field mt-2">
			              	 <button class="btn btn btn-primary " >
			                   <span class="align-middle d-sm-inline-block d-none">Get Details</span>
			                </button>
			              </div>
                         
			           </div>
			           </form>
                     <form action="<?php echo site_url('admin/Data/deposit_db') ?>" method="post" class="ajax-form">

                  <div class="row">
                  	<div class="form-group col-md-3 ">
			         <div class="row ">
			         	  <input type="Hidden" name="id" value="<?php echo $id ?>">
			         	  	 
			             <div class="form-group col-md-12 ajax-field">
			              <label class="form-label" for="account_no">Account Number</label>
			              <input type="text" name="account_no" id="account_no" class="form-control" placeholder=" " value="<?= $account_no?>" readonly />
			               <div class="ajax-error"></div>
			            </div>
			             <div class="form-group col-md-12 ajax-field">
			              <label class="form-label" for="last_name">User Name</label>
			              <input type="text" name="full_name" id="last_name" class="form-control" placeholder=" " value="<?= $full_name?>" readonly />
			               <div class="ajax-error"></div>
			            </div>
			             <div class="form-group col-md-12 ajax-field">
			              <label class="form-label" for="username">Mobile </label>
			              <input type="text" name="mobile" id="mobile" class="form-control" placeholder="" value="<?= $mobile?>" readonly />
			               <div class="ajax-error"></div>
			            </div>
			              <div class="form-group col-md-12 ajax-field">
			              <label class="form-label" for="username">Current Balanace</label>
			              <input type="text" name="curr_bal" id="curr_bal" class="form-control" placeholder="" value="<?= $curr_bal?>" readonly/>
			               <div class="ajax-error"></div>
			            </div>
			             <div class="form-group col-md-12 ajax-field ajax-field">
			              <label class="form-label" for="email">Deposit Amount</label>
			              <input type="text" name="deposit" id="email" class="form-control" placeholder="" value="" />
			               <div class="ajax-error"></div>
			            </div>
			             
			            <div class="d-flex justify-content-between mx-2">
			            	<button class="btn btn btn-primary " >
			            		<span class="align-middle d-sm-inline-block d-none">Save</span>
			            	</button>

			            </div>
			            
			          </div>
			         </div>
                   </div>

			          
			        </form>
			       
			      </div>
			  <!-- /Horizontal Wizard -->   
			     
			   

			     
			    </div>
			  </div>
			</section>

		
        </div>
       </div>
      </div>
      <!-- end ccontent -->



   

<?php $this->load->view('admin/common/footer') ?>

  <script type="text/javascript">
      $(document).ready(function(){
        
        $(document).on('submit', '.ajax-form', function(e){
          e.preventDefault();
          clearAjaxErrors();
          var url = $(this).attr('action');
          var data = $(this).serializeArray();
          $.post(url, data, function(res){
            processAjaxResponse(res);
          }, 'json');
        });

      });

   
    </script>