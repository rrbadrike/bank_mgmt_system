<?php $this->load->view('admin/common/header') ?>



    <!-- BEGIN: Content-->
    <div class="app-content content ">
      <div class="content-overlay"></div>
      <div class="header-navbar-shadow"></div>
      <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
          <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h2 class="content-header-title float-left mb-0"> Transaction List</h2>
                <div class="breadcrumb-wrapper">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a>
                    </li>
                   <!--  <li class="breadcrumb-item"><a href="#">Data</a>
                    </li> -->
                    <li class="breadcrumb-item active"> Transaction List
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>

         <!--  <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
            <div class="form-group breadcrumb-right">
              <div class="dropdown">
                <button class="btn-icon btn btn-primary btn-round btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" onclick="window.location='<?php echo site_url("admin/Data/add_member") ?>'">Add New Member</button>
              
              </div>
            </div>
          </div>  -->

        </div>
        <div class="content-body">

   <div >
     <div class="card">
     	 <form>
     	    <div class="row card-body">
			         
			            
			            <div class="form-group col-md-2 ajax-field">
			              <label class="form-label" for="email">Name</label>
			              <input type="text" name="name" id="first_name" class="form-control" placeholder="Customer Name" aria-label="john.doe" value="<?= $name?>"
			              />
			              
			            </div>
			            <div class="form-group col-md-2 ajax-field">
			              <label class="form-label" for="username">Mobile</label>
			              <input type="text" name="mobile" id="mobile" class="form-control" placeholder="mobile" value="<?= $mobile?>" />
			               
			            </div>
			             <div class="form-group col-md-2 ajax-field">
			              <label class="form-label" for="username">Account No</label>
			              <input type="text" name="account_no" id="whatsapp" class="form-control" placeholder="Account" value="<?= $account_no?>" />
			             </div>
			           <!-- 
			            <div class="form-group col-md-2 ajax-field ajax-field">
                      <label class="form-label" for="from_date">From Date</label>
                      <input type="date" name="from_date" id="from_date" class="form-control" placeholder="from date" value="<?= $from_date ?>" />
                   </div>
                    <div class="form-group col-md-2 ajax-field ajax-field">
                      <label class="form-label" for="from_date">To Date</label>
                      <input type="date" name="to_date" id="to_date" class="form-control" placeholder="from date" value="<?= $to_date ?>" />
                   </div> -->

			             <div class="form-group col-md-2 ajax-field ajax-field">
			             	 <div class="form-label" for="email">&nbsp;</div>
			             <button class="btn btn-primary">Search</button>
                     <button class="btn btn-primary" type='button' onclick="window.location='<?php echo site_url("admin/Data") ?>'">Reset</button>
			             </div>
			          
			 </div>
		 </form>
     </div>
   </div>

        	<!-- Horizontal Wizard -->
        	<div class="ajax-msg"></div>
			<div class="row" id="basic-table">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
       
      </div>
                  <?php
                     $starts_from = ($per_page * ($page - 1)) + 1;
                     $end_to = $starts_from + $per_page - 1;
                     if ($end_to > $num_rows) {
                       $end_to = $num_rows;
                     }
                     $entries_text = "Showing " . $starts_from . " to " . $end_to . " of " . $num_rows . " entries";
                     ?>
          <p class="card-text ml-1"><?php echo $entries_text; ?></p>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
            	<th>Sr. No.</th>
            	<th>Full Name</th>
            	<th>Account No</th>
              <th>Mobile</th>
            	<th>Credit</th>
            	<th>Debit</th>
              <th>On Date</th>
            </tr>
          </thead>
          <tbody>
           <?php if(!empty($list)){
           	     $i=0;
                    foreach ($list as $key => $value) {
                    	$i++;
             	?>
            <tr>
              <td>
               <?php echo $i ?>
             </td>
             <td><?php echo $value['name'] ?></td>
             <td><?php echo $value['account_no'] ?></td>
             <td><?php echo $value['mobile'] ?></td>
             <td><?php echo $value['credit'] ?></td>
             <td><?php echo $value['debit'] ?></td>
             <th><?php echo date('d M Y h:i a',strtotime($value['on_date'])) ?></th>          
             
            </tr>
        <?php }}?>
         
          </tbody>
        </table>
		
        
      </div>
	 
        <?php echo pagination($num_rows, $per_page, $page, $url); ?>
		
    </div>
    
  </div>
</div>
        </div>
       </div>
      </div>
      <!-- end ccontent -->
        


  

<?php $this->load->view('admin/common/footer') ?>

  <script type="text/javascript">
      $(document).ready(function(){
        
        $(document).on('submit', '.ajax-form', function(e){
          e.preventDefault();
          clearAjaxErrors();
          var url = $(this).attr('action');
          var data = $(this).serializeArray();
          $.post(url, data, function(res){
            processAjaxResponse(res);
          }, 'json');
        });

         $(document).on('click', '.delete', function(e){
          e.preventDefault();
          clearAjaxErrors();
	          if(confirm("Are you sure to delete?")){
	          	  var id=$(this).attr('data-id');
	              var url="<?php echo site_url('admin/Data/delete_member/')?>"+id;
		          $.post(url, {id:id}, function(res){
		            processAjaxResponse(res);
		          }, 'json');
	          }
          
        });

      });

      $(document).ready(function(){

       $('[name=state_id]').trigger('change');
        var url="<?php echo base_url('admin/master/get_city') ?>";
            $.post(url, {state_id:$('[name=state_id]').val()}, function(res) {
              // var mydata=JSON.parse(res);
              // console.log(res);
             $('#city_name').empty();
			  $.each(res.list,function(idx,val){
				 // console.log(val);
				   $('#city').append('<option value="'+val.city_id+'">'+val.city_name+'</option>');
			  } );
               var s="<?php echo $city_id ?>";
               setTimeout(function(){
                $('#city_name').val(s);
              },1000)
            


            }, 'json');
     });
 
      $('#state_id').on('change', function(e) {
            e.preventDefault();
           // clearAjaxErrors();
          console.log('called');
            var url="<?php echo base_url('admin/master/get_city') ?>";
			 $('#city_name').empty();
            $.post(url, {state_id:$('[name=state_id]').val()}, function(res) {
             
			  $.each(res.list,function(idx,val){
				 
				   $('#city_name').append('<option value="'+val.city_id+'">'+val.city_name+'</option>');
			  } );
            }, 'json');
        });
	  
	 
    </script>