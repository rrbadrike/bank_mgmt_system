<?php 
function create_folder($path = ''){
    $directoryName = $path;
    if(!is_dir($directoryName)){
        mkdir($directoryName, 0777, true);
    }
}

   
function pagination($total, $per_page = 10, $page = 1, $url = '?') {
    $adjacents = "2";
    $page = ($page == 0 ? 1 : $page);
    $start = ($page - 1) * $per_page;
    $prev = $page - 1 ? $page - 1 : 1;
    $next = $page + 1;
    $lastpage = ceil($total / $per_page);
    $lpm1 = $lastpage - 1;
    $pagination = '';
    if ($lastpage > 1) {
        $pagination .= '<div class="row" style="margin-top: 10px;">
                             <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12" style="float:left;">
                             <nav aria-label="Page navigation example">';
        $pagination .= '<ul class="pagination mt-2">';
        // $pagination .= "<li class='details mr-2'><h6 style='margin-bottom:0px;'>Page $page of $lastpage</h6></li>";
        $pagination .= "<li class='page-item prev'><a class='page-link' href='{$url}page=$prev'>Prev</a></li>";
        if ($lastpage < 7 + ($adjacents * 2)) {
            for ($counter = 1; $counter <= $lastpage; $counter++) {
                if ($counter == $page)
                    $pagination .= "<li class='page-item active'><a class='page-link'>$counter</a></li>";
                else
                    $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$counter'>$counter</a></li>";
            }
        }
        elseif ($lastpage > 5 + ($adjacents * 2)) {
            if ($page < 1 + ($adjacents * 2)) {
                for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++) {
                    if ($counter == $page)
                        $pagination .= "<li class='page-item active'><a class='page-link'>$counter</a></li>";
                    else
                        $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$counter'>$counter</a></li>";
                }
                $pagination .= "<li class='page-item'>...</li>";
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$lpm1'>$lpm1</a></li>";
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$lastpage'>$lastpage</a></li>";
            }
            elseif ($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2)) {
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=1'>1</a></li>";
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=2'>2</a></li>";
                $pagination .= "<li class='page-item'>...</li>";
                for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++) {
                    if ($counter == $page)
                        $pagination .= "<li class='page-item active'><a class='page-link'>$counter</a></li>";
                    else
                        $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$counter'>$counter</a></li>";
                }
                $pagination .= "<li class='page-item' class='dot'>..</li>";
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$lpm1'>$lpm1</a></li>";
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$lastpage'>$lastpage</a></li>";
            }
            else {
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=1'>1</a></li>";
                $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=2'>2</a></li>";
                $pagination .= "<li class='page-item'>..</li>";
                for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++) {
                    if ($counter == $page)
                        $pagination .= "<li class='page-item active'><a class='page-link'>$counter</a></li>";
                    else
                        $pagination .= "<li class='page-item'><a class='page-link' href='{$url}page=$counter'>$counter</a></li>";
                }
            }
        }
        if ($page < $counter - 1) {
            $pagination .= "<li class='page-item next'><a class='page-link' href='{$url}page=$next'>Next</a></li>";
            
        } else {
            $pagination .= "<li class='page-item next'><a class='page-link'>Next</a></li>";  // 
        }
        $pagination .= "</ul></nav>";
      
    }
     $pagination .= "</div></div>";
    return $pagination;
}

function logo_url(){
    return base_url('app-assets/images/logo/logo.jpg');
}

function upload_url(){
    return site_url('common/file_upload');
}

function time_diffrence($timestamp) {
     $today = new DateTime(date('Y-m-d H:i:s'));
     //$thatDay = new DateTime('Sun, 10 Nov 2013 14:26:00 GMT');
     $thatDay = new DateTime($timestamp);
     $dt = $today->diff($thatDay);
      if ($dt->y > 0) {
       $number = $dt->y;
        $unit = "year";
    } else if ($dt->m > 0) {
        $number = $dt->m;
        $unit = "month";
    } else if ($dt->d > 0) {
        $number = $dt->d;
        $unit = "day";
    } else if ($dt->h > 0) {
          $number = $dt->h;
          $unit = "hour";
    } else if ($dt->i > 0) {
         $number = $dt->i;
         $unit = "minute";
    } else if ($dt->s > 0) {
        $number = $dt->s;
        $unit = "second";
    }

    $unit .= $number > 1 ? "s" : "";
    $ret = $number . " " . $unit . " " . "ago";
    return $ret;
}