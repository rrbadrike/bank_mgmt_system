<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common extends CI_Controller {
     
     function __construct(){
		parent::__construct();
	    $this->session->userdata('admin');
		$this->admin = $this->session->userdata('admin');
		$this->load->model('Auth_model');
	}

	  function getStates()
    {
        $state = $msg = "";
        $status = 0;
        $countryId = $_POST['country_id'];
        $array=array();
        $array['country_id']=$countryId;
        $data=post_call('/common/states',json_encode($array));
        $mydata2=json_decode( $data);
        $getState=$mydata2->data->list;
        //$getState = $this->States_model->get_data($countryId);
        if (isset($getState) && !empty($getState)) {
            $state .= '<option value="">Select State</option>';
            foreach ($getState as $getState_val) {
                $state .= "<option value='" . $getState_val->state_id . "'>" . ucwords($getState_val->state_name) . "</option>";
                $status = 1;
            }
        }
        $return = array();
        $return['status'] = $status;
        $return['msg'] = $msg;
        $return['data'] = $state;
        echo json_encode($return);
    }

    function file_upload() {
        $response = array();
        $files = array();
        $error = array();

        create_folder('./uploads/temp');

        $config = array();
        $config['upload_path']   = './uploads/temp'; 
        $config['allowed_types'] = '*'; 
        $config['encrypt_name'] = TRUE; 
        $this->load->library('upload', $config);

        if(isset($_FILES['files']['name'][0]) && !empty($_FILES['files']['name'][0])){
            $length = count($_FILES['files']['name']);
            for($i = 0 ; $i < $length ; $i++){
                $_FILES['file'] = array();
                $_FILES['file']['name'] = $_FILES['files']['name'][$i];
                $_FILES['file']['type'] = $_FILES['files']['type'][$i];
                $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
                $_FILES['file']['error'] = $_FILES['files']['error'][$i];
                $_FILES['file']['size'] = $_FILES['files']['size'][$i];

                if ( ! $this->upload->do_upload('file')) {
                    $error[] = $_FILES['files']['name'].' Error : '.$this->upload->display_errors();
                } else { 
                    $upload_data = $this->upload->data();
                    $file_name = $upload_data['file_name'];
                    $files[] = $file_name;//push filename in array

                 if(isset($_POST['resize']) && ($_POST['resize'] == 1)){//optional for resize image
                        $this->load->library('image_lib');

                        $config = array();
                        $config['image_library'] = 'gd2';
                        $config['source_image'] = 'uploads/temp/' . $file_name;

                        $file_name_ext = explode('.', $file_name);
                        $file_name_only = $file_name_ext[0];
                        $file_ext_only = $file_name_ext[1];

                        $config['new_image'] = 'uploads/temp/' . $file_name_only.'_resized.'.$file_ext_only;
                        $config['maintain_ratio'] = TRUE;
                        $config['width'] = isset($_POST['resize_width']) ? $_POST['resize_width'] : 250;
                        //$config['height'] = 290;
                        $this->image_lib->initialize($config);
                        $this->image_lib->resize();
                        $this->image_lib->clear();
                    }
                }
            }
        }
        $response['files'] = $files;
        $response['error'] = $error;
        echo json_encode($response);
    }

    function get_city(){
        $this->load->model('Master_model');
        $state_id=$this->input->post('state_id');
        $response = $this->Master_model->city_list($state_id);
        echo json_encode($response);
    }

}
