<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
     
     function __construct(){
        
		parent::__construct();
	    $this->session->userdata('admin');
		$this->admin = $this->session->userdata('admin');
		$this->load->model('Auth_model');
	}

	function index(){
       
		if(!empty($this->admin)){
			redirect('admin/Dashboard');
		}
		$this->load->view('admin/login');
	}

    function verify(){
		$response = $this->Auth_model->verify();
		
		echo json_encode($response);
	}

	function logout(){
		$this->session->unset_userdata('admin');
		redirect('admin/Login');
	}

}
