<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
     
     function __construct(){
		parent::__construct();
	    $this->session->userdata('admin');
		$this->admin = $this->session->userdata('admin');
		if(empty($this->admin)){
			redirect('Login');
		}
		$this->load->model('User_model');
     }

	function index(){
		$data=$this->User_model->user_list();
		$data['active_tab']='user';
		$data['active_sub_tab']='user_list';
		$this->load->view('admin/user/list',$data);
	}

	function add($id=''){
		$data=array();
		$data['active_tab']='user';
		$data['active_sub_tab']='add_user';
		if(!empty($id)){
         $data['edit']=$this->User_model->get_data(base64_decode($id));
		}
		$data['account_no']=$this->User_model->get_last_id();
		$this->load->view('admin/user/add',$data);
	}
    
    function add_user_db(){
    	$res=$this->User_model->add_user_db();
    	echo json_encode($res);
    }

    function delete_user($id=''){
       $res=$this->User_model->delete_user(base64_decode($id));
    	echo json_encode($res);
    }

   

}
