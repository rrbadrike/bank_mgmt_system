<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
     
     function __construct(){
		parent::__construct();
	    $this->session->userdata('admin');
		$this->admin = $this->session->userdata('admin');
		if(empty($this->admin)){
			redirect('Login');
		}
		$this->load->model('User_model');
     }

	function index(){
		$data=array();
		$_GET['today']=date('Y-m-d');
		$data=$this->User_model->dashboard_history_list();
    	$data['active_tab']='dashboard';
		$data['active_sub_tab']='';
		$this->load->view('admin/dashboard',$data);
	}

  

}
