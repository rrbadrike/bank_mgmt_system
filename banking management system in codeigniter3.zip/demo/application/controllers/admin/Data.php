<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data extends CI_Controller {
     
     function __construct(){
		parent::__construct();
	    $this->session->userdata('admin');
		$this->admin = $this->session->userdata('admin');
		if(empty($this->admin)){
			redirect('Login');
		}
		$this->load->model('Data_model');
		
     }

	function index(){
		$data=$this->Data_model->transaction_list();
		$data['active_tab']='data';
		$data['active_sub_tab']='member_list';
		$this->load->view('admin/data/transaction_list',$data);
	}

	

	function deposit($id=''){
		$data=array();
		$data['active_tab']='data';
		$data['active_sub_tab']='add_member';
        $acc_no=!empty($_GET['account_no'])?$_GET['account_no']:"";
		if(!empty($acc_no)){
         $data['edit']=$this->Data_model->get_data($acc_no);
		}
	    $this->load->view('admin/data/deposit.php',$data);
	}
	
	function withdraw(){
		$data=array();
		$data['active_tab']='data';
		$data['active_sub_tab']='add_member';
        $acc_no=!empty($_GET['account_no'])?$_GET['account_no']:"";
		if(!empty($acc_no)){
         $data['edit']=$this->Data_model->get_data($acc_no);
		}
	    $this->load->view('admin/data/withdraw.php',$data);
	}
    
    function deposit_db(){
    	$res=$this->Data_model->deposit_db();
    	echo json_encode($res);
    }

    function withdraw_db(){
    	$res=$this->Data_model->withdraw_db();
    	echo json_encode($res);
    }

    function delete_member($id=''){
       $res=$this->Data_model->delete_member(base64_decode($id));
    	echo json_encode($res);
    }

   
}
