function processAjaxResponse(res, time = 1500, el = undefined){
	var status = false;
	//console.log(res['redirect_url']);
	if(res['status'] == 1){
		
		if(el){
			$(el).find('.ajax-msg').html('<div class="alert alert-success" role="alert"><div class="alert-heading">'+res['msg']+'</div></div>');
		}else{
			$('.ajax-msg').html('<div class="alert alert-success" role="alert"><div class="alert-heading">'+res['msg']+'</div></div>');
		}
		if(res['redirect_url']){

			setTimeout(function(){
				window.location.href = res['redirect_url'];
			}, time);
		}
		status = true;
	}else if(res['status'] == 0){
		if(res['error'] && res['error'] != ''){
			$('.ajax-msg').html('<div class="alert alert-danger" role="alert"><div class="alert alert-heading">'+res['error']+'</div></div>');
		}else if(res['error_array']){
			Object.keys(res['error_array']).map(function(key){
				//console.log(key);
				//console.log(res['error_array'][key]);
				// $('[name="'+key+'"]').closest('.ajax-field').find('span').html(res['error_array'][key]);
				$('[name="'+key+'"]').closest('.ajax-field').find('.ajax-error').html(res['error_array'][key]);
			});
		}
	}
	$('html, body').animate({
        scrollTop: 0
    }, 500);
    return status;
}

function clearAjaxErrors(el){
	if(el){
		$(el).find('.ajax-error').html('');
		$(el).find('.ajax-msg').html('');
	}else{
		$('.ajax-error').html('');
		$('.ajax-msg').html('');
	}
}

function fillAjaxForm(data){
	Object.keys(data).map(function(key){
		$('#ajax-form').find('[name="'+key+'"]').val(data[key]);
	});
}

function uploadFile(el, url){
	var form_data = new FormData();
	var totalfiles = el.files.length;
	for (var index = 0; index < totalfiles; index++) {
      	form_data.append("files[]", el.files[index]);
   	}

   	$.ajax({
	    url: url, 
	    type: 'POST',
	    data: form_data,
	    dataType: 'json',
	    cache: false,
	    contentType: false,
	    processData: false,
	    xhr: function() {
            var xhr = new window.XMLHttpRequest();
            xhr.upload.addEventListener("progress", function(evt) {
                if (evt.lengthComputable) {
                	var percent = Math.round((evt.loaded / evt.total) * 100);
                	$(el).closest('.ajax-field').find('.ajax-error').html('<p style="color:green;">Upload progress : '+percent+'%');
                	if(percent == 100){
                		$(el).closest('.ajax-field').find('.ajax-error').html('');
                	}
                }
            }, false);
            return xhr;
        },
	    success: function (response) {

	    }
   });
}

function show_loader(){
	$('#custom-loader').css('display', 'flex');
}

function hide_loader(){
	$('#custom-loader').css('display', 'none');
}

    /*  $("#geolocation").bind("geocode:result", function(event, latLng) {// geocode:dragged
              // console.log(latLng.geometry.location.lat());
               var geolocation=latLng.geometry.location;
               var lat=latLng.geometry.location.lat();
                var longi=latLng.geometry.location.lng();
                $("input[name=latitude]").val(lat);//latLng.lat()
                $("input[name=longitude]").val(longi);//latLng.lng()
                var map = $("#geolocation").geocomplete("map");
                map.panTo(geolocation);//latLng
                var geocoder = new google.maps.Geocoder();
                geocoder.geocode({
                    'latLng': geolocation//latLng
                }, function(results, status) {
                //	alert('ok');
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (results[0]) {
                            var geo_address = results[0].address_components;

                            geo_address.reverse();
                            var fields_array = {
                                '0': 'pincode',
                                '1': 'country',
                                '2': 'state',
                                '4': 'city',
                                '5': 'area'
                            };
                            var formate_address = [];
                            $.each(geo_address, function(i, j) {
                                formate_address.push(j.long_name);

                            });
                            $('[name="city"]').val(formate_address[4]);

                            formate_address.reverse();
                            var address2 = formate_address.splice(0, 4);

                            //   $('[name="map_address1"]').val(address2);
                           // console.log(address2);
                            $('[name="address"]').val(formate_address);
                            $('[name="venue"]').val(formate_address);

                        }
                    }
                });
            });*/
